%% initial look on the data
close all; clear;

% load measurements
load('track.mat');

% plot measurements
figure; hold on; grid on;
plot3(positions(1,:), positions(2,:), positions(3,:),...
    positions(1,1), positions(2,1), positions(3,1), 'r+');

%% Derivatives
% velocities
steps = ...; % [d/dx; d/dy; d/dz]
timeSteps = ...; % [dt/dx]=[dt/dy]=[dt/dz]
xVelocity = ...; % velocity in x-direction
yVelocity = ...; % velocity in y-direction
zVelocity = ...; % velocity in z-direction

%% Norms
speed = ...
    
% plot speed
figure; hold on; grid on;
plot(..., ...,'b-');
ylabel('m/s'); xlabel('s');
legend('Speed');

% (Optional) length of bike trip


%% Rank

% (18)
A = ...
b = ...

% check if A has full rank
...

x = ...; % calculate x

r_actual = ... % select actual radius from x

%% Eigenvalues and Eigenvectors

A = ...; % transformation matix

[V, D] = ...; %calculate eigenvalues and eigenvectors
eigenVectors = ...; % scale eigenvectors with eigenvalues

% references: unit circle & unit square
unitCircle = [cos(linspace(0,2*pi,50)); sin(linspace(0,2*pi,50))]; 
unitSquare = [1 1 -1 -1 1;1 -1 -1  1 1];

ellipse = A * unitCircle;
parallelogram = A * unitSquare;

mm = 2.5; % axis limit
figure; hold on; grid on; axis([-mm mm -mm mm]); axis equal;
plot(...,...); % plot unitSquare
plot(...,...); % plot parallelogram
quiver(0,0,eigenVectors(1,1),eigenVectors(2,1),0);
quiver(0,0,eigenVectors(1,2),eigenVectors(2,2),0);
xlabel('x'); ylabel('y');
legend('unit square', 'image of unit square','first eigenvector', 'second eigenvector');

figure; hold on; grid on; axis([-mm mm -mm mm]); axis equal;
plot(...,...); % plot unitCircle
plot(...,...); % plot ellipse
quiver(0,0,eigenVectors(1,1),eigenVectors(2,1),0);
quiver(0,0,eigenVectors(1,2),eigenVectors(2,2),0);
xlabel('x'); ylabel('y');
legend('unit square', 'image of unit square','first eigenvector', 'second eigenvector');


%% Matrix exponential (not asked)
% just an example so you have seen it
expm(eye(3))

%% Symmetric Matrices (optional)
% this can be done by hand! If you want to verify your solution go ahead.
% Hint: use 'syms' to define your sybolic variables

%% Positive / Negative (Semi-) Deinite
% this can be done by hand! If you want to verify your solution go ahead.
% Hint: to check that all eigen values are greater or equal than 0 use
%       all(eigenValuesOfYourMatrix >= 0)

%% Orthogonal matrices
% this can be done by hand! If you want to verify your solution go ahead.
% Hint: with 'isequal(A,B)' you can check if two matrices are equal.
%       You might run into trouble, since the computation accuracy is
%       limited and might need to check it against a threshold
%       all(all(matrixThatShouldBeZero <= eps))
%       'eps' is the machine precision

%% Upper / Lower Triangular Matrices
% this can be done by hand! If you want to verify your solution go ahead.

%% Diagonal matrices
% this can be done by hand! If you want to verify your solution go ahead.

%% Linear and Affine Functions
% this can be done by hand! If you want to verify your solution go ahead.

%% Quadratic Functions
% this can be done by hand! If you want to verify your solution go ahead.
